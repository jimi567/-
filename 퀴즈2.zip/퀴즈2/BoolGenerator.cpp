#include"BoolGenerator.h"
#include<string>
#include <vector>
#include <stdexcept>
#include <iostream>
using namespace std;

BoolGenerator & BoolGenerator::AddVarProp(const string &name){
  props.push_back(PropVar(name));
  return *this;
}
void BoolGenerator::Build(){
  if(props.empty())
        throw runtime_error("PropVars should not be empty");
  const int len = 1 << props.size();
  auto iter = props.begin();
  for (int pos = len/2; pos > 0; pos= pos/2, iter++){
    auto &prop = *iter;
    for (int idx = 0; idx < len; idx++){
      prop.rows.push_back(Generate(idx / pos));
    }
  }
}
bool BoolGenerator::Generate(const int num)
{
  return num % 2 == 0;
}

PropVar BoolGenerator::operator[](const int index){
  return props.at(index);
}

vector<PropVar> BoolGenerator::GetPropVars(){
  return this->props;
}
