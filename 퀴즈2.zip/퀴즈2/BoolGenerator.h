//20171583 김기범
#ifndef _BOOLGEN_H_
#define _BOOLGEN_H_
#include <iostream>
#include <string>
#include <vector>
#include<iomanip>
#include "PropVar.h"
using namespace std;

class BoolGenerator{
  bool Generate(const int num);
  vector<PropVar> props;
  inline friend std::ostream &operator<<(std::ostream &os, const BoolGenerator &gen);
public:
  BoolGenerator &AddVarProp(const string &name);
  void Build();
  PropVar operator[](const int index);
  vector<PropVar> GetPropVars();


};
inline ostream &operator<<(ostream &os, const BoolGenerator &gen)
{
  for (auto prop:gen.props){
    os << setw(6) << prop.name << " ";
  }
  os << endl;
  const int rows = int(gen.props[0].rows.size());
  const int cols = int(gen.props.size());
  for (int row = 0; row < rows; row++){
    for (int col = 0; col < cols ;col++)
            os << setw(7) << boolalpha << gen.props[col].rows[row];
    os << endl;
  }
  return os;
}
#endif
