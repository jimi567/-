
enum class PVAR{
  P,Q,R
};
