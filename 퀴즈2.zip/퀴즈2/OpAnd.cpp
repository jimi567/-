#include <iostream>
using namespace std;



class OpAnd
{
public:
  bool operator() (bool val1, bool val2);
};

bool OpAnd::operator()(bool val1 , bool val2)
{
  return val1 && val2;
}
