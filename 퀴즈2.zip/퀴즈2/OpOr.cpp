#include <iostream>
using namespace std;



class OpOr
{
public:
  bool operator() (bool val1, bool val2);
};

bool OpOr::operator()(bool val1 , bool val2)
{
  return val1 || val2;
}
