#include<vector>
#include <iostream>
#include<string>
#include<algorithm>
using namespace std;

class PropVar
{
public:
  PropVar(const std::string &name);
  PropVar(const string &name,vector<bool> rows);
  bool operator[](const int index);
  string name;
  vector<bool> rows;
};
