#include <iostream>
using namespace std;



class OpNot
{
public:
  bool operator() (bool val1);
};

bool OpNot::operator()(bool val1)
{
  return ~val1;
}
