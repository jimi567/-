#include <iostream>
using namespace std;



class OpXor
{
public:
  bool operator() (bool val1, bool val2);
};

bool OpXor::operator()(bool val1 , bool val2)
{
  return val1 ^ val2;
}
