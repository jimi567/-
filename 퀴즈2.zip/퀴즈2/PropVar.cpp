#include "PropVar.h"
using namespace std;
PropVar::PropVar(const string &name){
  this->name = name;
}
PropVar::PropVar(const string &name,const vector<bool> rows){
  this->name = name;
  this->rows = rows;
}
bool PropVar::operator[](const int index){
  return rows.at(index);
}
