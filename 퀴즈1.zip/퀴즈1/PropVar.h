#include<vector>
#include <iostream>
#include<string>
#include<algorithm>
using namespace std;

class PropVar
{
public:
  PropVar(const std::string &name);
  string name;
  vector<bool> rows;
};
