#include<iostream>
#include<fstream>
#include<cstdlib>
#include<iomanip>
#include"BoolGenerator.h"
using namespace std;

int main(int argc, char* argv[])
{
  cout <<"진리표 퀴즈 1"<< endl;
  std::ofstream output;
  try
  {
    BoolGenerator gen;
    gen
    .AddVarProp("P")
    .AddVarProp("Q")
    .AddVarProp("S")
    .AddVarProp("T")
    .AddVarProp("Z")
    .AddVarProp("R")
    .Build();
    std::cout << gen << std::endl;

    //output.exception(ofstream::failbit | ofstream::badbit);
    output.open("TruthTable.out");
    output << gen;
    output.close();
  }
  catch (const std::exception &ex)
  {
    output.close();
    std::cerr << ex.what() << std::endl;
  }
return 0;

}
