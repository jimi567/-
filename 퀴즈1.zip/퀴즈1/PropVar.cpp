#include "PropVar.h"
using namespace std;
PropVar::PropVar(const string &name){
  this->name = name;

}
